<?php
$agreeLink="https://t.fastrk1.com/aff_c?offer_id=565&aff_id=3923&aff_sub=bbb-32";  //agree link

if(count($_GET)>0){
	foreach ($_GET as $key => $value) { 
	   $urlString.="&".$key."=".$value;
	}
   $tids="?".substr($urlString,1);
   $agreeLink.=$tids;
}
?>
<!DOCTYPE html>

<!--[if lt IE 7]>     <html class="no-js lt-ie9 lt-ie8 lt-ie7" xmlns:fb="http://ogp.me/ns/fb#"><![endif]-->

<!--[if IE 7]>        <html class="no-js lt-ie9 lt-ie8" xmlns:fb="http://ogp.me/ns/fb#"><![endif]-->

<!--[if IE 8]>        <html class="no-js lt-ie9" xmlns:fb="http://ogp.me/ns/fb#"><![endif]-->

<!--[if gt IE 8]><!--><html class="no-js" xmlns:fb="http://ogp.me/ns/fb#"><!--<![endif]-->

    <head>

        <meta charset="utf-8">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title>¡MÉTODO "BÍBLICO" PARA ESTIMULAR EL METABOLISMO Y REDUCIR RÁPIDAMENTE DE TALLAS!</title>

        <meta name="description" content="¡MÉTODO BÍBLICO PARA ESTIMULAR EL METABOLISMO Y REDUCIR RÁPIDAMENTE DE TALLAS!">

		<meta name="keywords" content="¡MÉTODO BÍBLICO PARA ESTIMULAR EL METABOLISMO Y REDUCIR RÁPIDAMENTE DE TALLAS!">

        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

        <link rel="stylesheet" href="mobile/css/normalize.min.css" type='text/css'>

		<link rel="stylesheet" href="mobile/css/presell.min.css" type='text/css'>
        
        <link rel="stylesheet" href="mobile/css/mobile.css" type='text/css'>

        <link href='//fonts.googleapis.com/css?family=Shadows+Into+Light+Two' rel='stylesheet' type='text/css'>        
		
		<style>

                </style>

        <script src="mobile/js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
		
		<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '273300203113872');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=273300203113872&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<script>
  fbq('track', 'ViewContent');
</script>


            </head>

    <body>

    <!--[if lt IE 7]>

    <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a>

    or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>

    <![endif]-->


    <div class="wrapper main clearfix">

                <div id="headerBox" class="clearfix">

                        <aside id="imageBox">
		<a href="#" onclick="window.location='https://t.fastrk1.com/aff_c?offer_id=565&aff_id=3923&aff_sub=bbb-32'"   id="image" data-tracking-suffix="i" onclick="fbq('track', 'Lead');" >
				<img style="border:0px solid #222;margin:16px 0px 17px;0px;" src="bild2.jpg" id="q1-image" class="headerImage" data-step="1">
				</a>
				
            </aside>

            <section id="headerContent">

                <header id="headerTitle">

                    <h2><a style="color: #77add7; text-decoration: none" href="#" onclick="window.location='https://t.fastrk1.com/aff_c?offer_id=565&aff_id=3923&aff_sub=bbb-32'"  id="headline" data-tracking-suffix="h" onclick="fbq('track', 'Lead');">¡MÉTODO "BÍBLICO" PARA ESTIMULAR EL METABOLISMO Y REDUCIR RÁPIDAMENTE DE TALLAS!</a></h2>
					<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
                </header>

                <section id="headerText">
				
				
				<p>La experta en nutrición Kristina Wilds ha descubierto la <b>VERDADERA</b> causa del exceso de grasa abdominal (<b>Pista</b>: <b>NO</b> es "comer demasiado y no hacer suficiente ejercicio"), que en realidad puede ser revertido como validada tanto por la comunidad científica como por los mejores médicos de todo el mundo.</p>
                   		
				<p>Su increíble plan de nutrición funciona tan bien que la industria de la gran dieta y pérdida de peso, que hace  <b>miles de millones</b> de dólares de su  <b>dolor</b> y <b>sufrimiento</b> seduciéndole para que compre su próximo producto, la ha estado amenazando desde que reveló sus descubrimientos bíblicos al público.</p>
                   		
				<p><b>===> Tome la prueba de 30 segundos para averiguarlo ahora <===</b>
				</p>
				
						
				
                </section>

            </section>

        </div>

        <div id="surveyBox" class="clearfix">

            <div id="questionBox" class="clearfix">

                <article id="step1" class="questionStep clearfix" data-step="1">
<header>PREGUNTA 1:</header>
<h6>¿Usted o alguien que usted conoce trabaja para la industria de la salud y la pérdida de peso en los Estados Unidos?
</h6>
<button class="stepButton yesBtn s1" data-step="1">Sí</button>
<button class="stepButton noBtn s1" data-step="1" href="">No</button>
</article>
<article id="step2" class="questionStep clearfix" data-step="2">
<header>PREGUNTA 2:</header>
<h6>¿Cree que la pérdida de peso sólo se puede lograr a través de dietas restrictivas o ejercicios agotadores?
</h6>

<button class="stepButton yesBtn s2" data-step="2">Sí</button>
<button class="stepButton noBtn s2" data-step="2" href="">No</button>
</article>
<article id="step3" class="questionStep clearfix" data-step="3">
<header>PREGUNTA 3:</header>
<h6>En el pasado, ¿ha recuperado su cuerpo el peso después de seguir planes de dieta típicos?
</h6>
<button class="stepButton yesBtn s3" data-step="3">Sí</button>
<button class="stepButton noBtn s3" data-step="3" href="">No</button>
</article>
<article id="step4" class="questionStep clearfix" data-step="4">
<header>PREGUNTA 4:</header>
<h6>¿Tiene 40 años o más y al menos 10 libras de sobrepeso?
</h6>
<button class="stepButton yesBtn s4" data-step="4">Sí</button>
<button class="stepButton noBtn s4" data-step="4" href="">No</button>
</article>
            </div>

            <div id="surveyEval" class="clearfix">

                <h3 id="pss1-title" class="evalTitle" data-step="1">Verificando con nuestro Smart Match System™ patentado</h3>
<h3 id="pss2-title" class="evalTitle" data-step="2">Pregunta 1: Válido</h3>
<h3 id="pss3-title" class="evalTitle" data-step="3">Pregunta 2: Válido</h3>
<h3 id="pss4-title" class="evalTitle" data-step="4">Pregunta 3: Válido</h3>
<h3 id="pss5-title" class="evalTitle" data-step="5">Pregunta 4: Válido</h3>
<img src="mobile/img/loading.gif" alt="loading" id="loadingImage" class="loading"><aside id="pss1-text" class="evalText" data-step="1">Gracias. Estamos evaluando sus respuestas.</aside>
<aside id="pss2-text" class="evalText" data-step="2">Revisando nuestro Smart Match System™ patentado</aside>
<aside id="pss3-text" class="evalText" data-step="3">Comprobando....</aside>
<aside id="pss4-text" class="evalText" data-step="4">¡Aprobado! <span style="color:#021f38;"></span></aside>
<aside id="pss5-text" class="evalText" data-step="5">¡Por favor, lea nuestras 3 reglas ahora!</aside>
            </div>

            <div id="congratsBox" class="clearfix">

                <article id="surveyEnd">

                                        <header>

                        <h4>¡Felicitaciones! Antes de que usted vea la presentación donde Kristina Wilds compartirá sus descubrimientos de 'Nutrición Bíblica' con usted, nuestros abogados nos han pedido que exijamos que cada persona esté de acuerdo con las siguientes pautas:
</h4>

                    </header>

                    <section>

<div style="color:#FFFFFF;font-size:16px;text-align:left;">
<span><p><img src="1.png" style="vertical-align:middle;padding-left:5px;padding-right:5px;">Usted NO debe hablar de los detalles de esta presentación con NADIE debido a los secretos de gran pérdida de peso que contiene. 



</p></span>
<span><p><img src="2.png" style="vertical-align:middle;padding-left:5px;padding-right:5px;">NO abuse de los consejos de Kristina Wilds sólo para que pueda seguir comiendo cantidades excesivas de alimentos y bocadillos azucarados.  
</p></span>
<span><p><img src="3.png" style="vertical-align:middle;padding-left:5px;padding-right:5px;">Esta presentación SOLAMENTE está disponible para un grupo selecto de personas y será ELIMINADA si Kristina Wilds se encuentra bajo demasiada presión por parte de la industria de la gran dieta y pérdida de peso. Si usted no quiere descubrir estos secretos de la industria, por favor 
<u>CIERRE INMEDIATAMENTE ESTA VENTANA </u> para liberar su espacio para la siguiente persona en la fila.</p></span>

                <p style="padding-left:60px;color:#000000;">Si está de acuerdo con todo lo anterior, haga clic en el botón "ESTOY DE ACUERDO" de abajo para proceder a la siguiente presentación privada.

</p>

</div>
                     </section>

                                                            <button id="surveyAgree" class="stepButton yesBtn" onclick="fbq('track', 'Lead');" href="<?php echo $agreeLink;?>">¡ESTOY DE ACUERDO!</button>

                                    </article>
									

            </div>

        </div>

    </div>

          <div id="footer">&copy <script type="text/javascript">var cur = 2014; var year = new Date(); if(cur == year.getFullYear()) year = year.getFullYear(); else year = cur + ' - ' + year.getFullYear(); document.write(year);</script>
		            <p style="text-align: center;"><span style="font-size: x-small;"><a href="privacy-policy.html">Privacy</a> | <a href="terms-of-service.html">Terms</a> | <a href="disclosure-agreement.html">Earnings</a> | <a href="contact.php">Contact</a></span></p>
					<p>This site is not a part of the Facebook website or Facebook Inc. Additionally, this is NOT endorsed by Facebook in any way. FACEBOOK is a trademark of FACEBOOK, INC.</p>
</div>

     <script>

    var noTimeLeft  = "a few seconds";

    var minutesTxt  = " minutes and ";

    var secondsTxt  = " seconds";

    var redirTime   = "28800";

    var trackEvents = "1";

    </script>

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
    <script src="mobile/js/presell.min.js"></script>

</body>
</html>